from django.shortcuts import render, redirect
from .models import Auto


def lista_autos(request):
    autos = Auto.objects.all()

    return render(request, 'autos/lista_autos.html', {
        'autos': autos
    })


def agregar_auto(request):

    if request.method == 'POST':
        marca = request.POST.get('marca')
        modelo = request.POST.get('modelo')
        anio = request.POST.get('anio')
        precio = request.POST.get('precio')

        Auto.objects.create(
            marca=marca,
            modelo=modelo,
            anio=anio,
            precio=precio
        )

        return redirect('lista_autos')

    return render(request, 'autos/agregar_auto.html')